### Docker-Exercise

The Exercise folder contains files and projects for the exercises. Each exercise has its own folder and README.md file with instructions.

Solutions can also be found in the respective folders.

- [Exercise Docker](Exercise-Docker/)
- [Solution Docker](Solution-Docker/)
- [Exercise Dev Container](Exercise-Dev-Container/)
- [Solution Dev Container](Solution-Dev-Container/)
