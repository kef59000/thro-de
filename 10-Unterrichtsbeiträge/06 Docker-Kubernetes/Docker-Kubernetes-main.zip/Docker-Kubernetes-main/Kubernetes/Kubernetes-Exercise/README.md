### Kubernetes-Exercise

The Exercise folder contains files and projects for the exercises. Each exercise has its own folder and README.md file with instructions.

Solutions can also be found in the respective folders.

- [Exercise Simple Pod](Exercise-Simple-Pod/)
- [Solution Simple Pod](Solution-Simple-Pod/)
- [Exercise Scaling](Exercise-Scaling/)
- [Solution Scaling](Solution-Scaling/)
- [Exercise Rolling Update Rollback](Exercise-Rolling-Update-Rollback/)
- [Solution Rolling Update Rollback](Solution-Rolling-Update-Rollback/)
- [Exercise Helm Portainer](Exercise-Helm-Portainer/)
