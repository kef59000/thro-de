### Docker-Demo

The Demo folder contains files and projects shown during the presentation.

- [Dockerfile](Demo-Dockerfile/)
- [Docker Compose](Demo-Docker-Compose/)
- [Dev Container](Demo-Dev-Container/)
