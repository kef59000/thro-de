### Kubernetes-Demo

The Demo folder contains files and projects shown during the presentation.

- [Demo Kubernetes Cluster](Demo-Kubernetes-Cluster/)
- [Demo Rolling Update](Demo-RollingUpdate/)
- [Demo Pod Eviction](Demo-Pod-Eviction/)
