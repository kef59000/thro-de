## selfservice analytics
This repository contains materials for a presentation on "self service analytics". Additionaly, it contains exercises to gain a first look and initial exposure on this subject area.

Table of contents:
- `./exercise_looker` contains an exercise to self service analytics with the tool google looker studio
- `./materials` additional appendix
